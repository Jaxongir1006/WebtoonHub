O‘zbekcha
Bitta asarning bir nechta bobini papka yoki ZIP orqali yuklang. Avval bob raqami va sahifalar tartibini tekshiring, so‘ng yuklashni boshlang.
Har bir bob uchun alohida papka yarating: Chapter 01, Chapter 02, Chapter 03.5. Sahifalarni o‘qish tartibida 001.jpg, 002.jpg kabi nomlang. Shablonni ochib, uning matnli eslatmalari yoniga haqiqiy rasmlaringizni qo‘ying. Bir importda faqat bitta asarning boblarini tanlang. “Papka tanlash” orqali My-Series asosiy papkasini, “ZIP tanlash” orqali shu tuzilma saqlangan arxivni tanlang. Bir bob uchun “Rasmlarni tanlash” ham ishlaydi.
Shablon ichida haqiqiy rasmlar yo‘q. Yuqoridagi daraxt tayyor papka qanday ko‘rinishini ko‘rsatadi; matnli eslatmalar importda o‘tkazib yuboriladi.

English
Upload several chapters of one series from a folder or ZIP. Review chapter numbers and page order before starting the upload.
Use one folder per chapter: Chapter 01, Chapter 02, Chapter 03.5. Name pages in reading order, such as 001.jpg and 002.jpg. Extract the template and place your real images alongside its text instructions. Include only one series in each import. Use “Choose folder” for the parent My-Series folder or “Choose ZIP” for an archive with the same structure. “Choose images” also works for a single chapter.
The template contains no actual images. The tree illustrates how your completed folder should look; text instruction files are skipped during import.

Русский
Загрузите несколько глав одного произведения из папки или ZIP. Перед загрузкой проверьте номера глав и порядок страниц.
Каждая глава должна быть в отдельной папке: Chapter 01, Chapter 02, Chapter 03.5. Назовите изображения по порядку чтения: 001.jpg, 002.jpg. Распакуйте шаблон и добавьте настоящие изображения рядом с текстовыми инструкциями. В одном импорте должны быть главы только одного произведения. Нажмите «Выбрать папку» для родительской папки My-Series или «Выбрать ZIP» для архива с такой же структурой. Для одной главы можно использовать «Выбрать изображения».
В шаблоне нет настоящих изображений. Дерево показывает пример готовой папки; текстовые инструкции при импорте пропускаются.

EXAMPLE / NAMUNA / ПРИМЕР
My-Series/
├── Chapter 01/
│   ├── 001.jpg
│   ├── 002.jpg
│   └── 003.jpg
├── Chapter 02/
│   ├── 001.png
│   └── 002.png
└── Chapter 03.5/
    ├── 001.webp
    └── 002.webp

Guide: admin/public/guides/chapter-import-guide.html
